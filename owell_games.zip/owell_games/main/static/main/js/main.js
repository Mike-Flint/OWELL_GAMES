let openORclose = false;

function button(el){
    let menu = document.getElementById("menu");
    let arrow = document.getElementById("arrow");
    let btn_language = document.getElementById("btn_language")
    if (menu){
        if (openORclose) {
            menu.style.display = "none";
            arrow.style.transform = "rotate(0deg)";
            btn_language.style.paddingBottom = "7px";
            openORclose = false;

        }
        else{
            menu.style.display = "block";
            arrow.style.transform = "rotate(-180deg)";
            btn_language.style.paddingBottom = "100px";
            openORclose = true;
        }
    }
}