from django.apps import AppConfig


class BoxStormConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Box_Storm'
